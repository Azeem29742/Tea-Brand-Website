import { useState } from "react";
import { ShoppingCart, Leaf, Instagram, Mail, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function TeaBrandWebsite() {
  const [cart, setCart] = useState([]);

  const teas = [
    { id: 1, name: "Green Harmony", price: "$12", img: "https://picsum.photos/300/200?1" },
    { id: 2, name: "Herbal Bliss", price: "$15", img: "https://picsum.photos/300/200?2" },
    { id: 3, name: "Classic Black", price: "$10", img: "https://picsum.photos/300/200?3" },
  ];

  const addToCart = (tea) => setCart([...cart, tea]);

  return (
    <div className="font-sans bg-emerald-50 min-h-screen">
      <header className="flex justify-between items-center p-6 bg-emerald-700 text-white shadow-md">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Leaf /> Nature’s Brew
        </h1>
        <div className="flex items-center gap-6">
          <nav className="hidden md:flex gap-6">
            <a href="#home" className="hover:text-yellow-200">Home</a>
            <a href="#about" className="hover:text-yellow-200">About</a>
            <a href="#shop" className="hover:text-yellow-200">Shop</a>
            <a href="#blog" className="hover:text-yellow-200">Blog</a>
            <a href="#contact" className="hover:text-yellow-200">Contact</a>
          </nav>
          <div className="relative">
            <ShoppingCart />
            {cart.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-yellow-400 text-black rounded-full px-2 text-xs">
                {cart.length}
              </span>
            )}
          </div>
        </div>
      </header>

      <section id="home" className="text-center py-20 bg-[url('https://picsum.photos/1200/500?tea')] bg-cover bg-center text-white">
        <h2 className="text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">Brewed with Nature, Served with Love</h2>
        <p className="mb-6 text-lg">Discover premium blends crafted from the finest tea leaves</p>
        <Button className="bg-yellow-400 text-black hover:bg-yellow-500">Shop Now</Button>
      </section>

      <section id="about" className="p-10 max-w-4xl mx-auto text-center">
        <h3 className="text-3xl font-semibold mb-4">Our Story</h3>
        <p className="text-gray-700 leading-relaxed">
          At Nature’s Brew, we believe tea is more than just a drink — it’s a ritual of wellness,
          culture, and connection. Our teas are ethically sourced, handpicked, and blended to bring you
          both comfort and vitality.
        </p>
      </section>

      <section id="shop" className="p-10 bg-white">
        <h3 className="text-3xl font-semibold text-center mb-6">Our Teas</h3>
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {teas.map((tea) => (
            <Card key={tea.id} className="rounded-2xl shadow-md">
              <img src={tea.img} alt={tea.name} className="rounded-t-2xl w-full h-48 object-cover" />
              <CardContent className="p-4">
                <h4 className="text-xl font-bold">{tea.name}</h4>
                <p className="text-gray-600">{tea.price}</p>
                <Button onClick={() => addToCart(tea)} className="mt-3 bg-emerald-700 hover:bg-emerald-800">Add to Cart</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section id="blog" className="p-10 bg-emerald-100">
        <h3 className="text-3xl font-semibold text-center mb-6">Tea Journal</h3>
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <div className="bg-white p-4 rounded-xl shadow">
            <h4 className="font-bold mb-2">Health Benefits of Green Tea</h4>
            <p className="text-gray-600">Green tea is rich in antioxidants and helps boost metabolism...</p>
          </div>
          <div className="bg-white p-4 rounded-xl shadow">
            <h4 className="font-bold mb-2">Brewing the Perfect Cup</h4>
            <p className="text-gray-600">Discover the art of steeping for flavor and aroma...</p>
          </div>
          <div className="bg-white p-4 rounded-xl shadow">
            <h4 className="font-bold mb-2">Herbal Teas for Relaxation</h4>
            <p className="text-gray-600">Chamomile, lavender, and peppermint teas can calm the mind...</p>
          </div>
        </div>
      </section>

      <section id="contact" className="p-10 text-center">
        <h3 className="text-3xl font-semibold mb-4">Get in Touch</h3>
        <p className="text-gray-700 mb-4">We’d love to hear from you! Reach us through the following channels:</p>
        <div className="flex justify-center gap-6">
          <a href="mailto:info@naturesbrew.com" className="flex items-center gap-2 text-emerald-700"><Mail /> info@naturesbrew.com</a>
          <span className="flex items-center gap-2 text-emerald-700"><Phone /> +92 300 1234567</span>
          <a href="#" className="flex items-center gap-2 text-emerald-700"><Instagram /> Instagram</a>
        </div>
      </section>

      <footer className="bg-emerald-700 text-white text-center py-6 mt-10">
        <p>&copy; {new Date().getFullYear()} Nature’s Brew. All rights reserved.</p>
      </footer>
    </div>
  );
}